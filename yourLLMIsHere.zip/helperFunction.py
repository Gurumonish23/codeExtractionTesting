from langchain_groq import ChatGroq
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain import hub
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
def textReader(fileName):
    with open(fileName, "r") as file:
        # Read all lines from the file and store them in a list
        lines = file.readlines()
        entire_file_content = ''.join(lines)
    return entire_file_content

def configuredLLM(globalDocuments):
	llm =ChatGroq(model='llama3-70b-8192')
	embeddings_model=GoogleGenerativeAIEmbeddings(model='models/embedding-001')
	splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
	globalDocuments=sum(globalDocuments, [])
	chunks = splitter.split_documents(globalDocuments)
	db = FAISS.from_documents(chunks,embeddings_model)
	retrieval_qa_chat_prompt = hub.pull("langchain-ai/retrieval-qa-chat")
	combine_docs_chain = create_stuff_documents_chain(llm, retrieval_qa_chat_prompt)
	rag_chain = create_retrieval_chain(db.as_retriever(), combine_docs_chain)
	file_path = BASE_DIR/"questionsAnsweringPrompt.txt"
	template=textReader(file_path)
	condense_question_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", template),
            ("placeholder", "{chat_history},{context}"),
            ("human", "{input}"),
        ]
    )
	history_aware_retriever = create_history_aware_retriever(llm, db.as_retriever(), condense_question_prompt)
	qa_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", template),
            ("placeholder", "{chat_history},{context}"),
            ("human", "{input}"),
        ]
    )
	qa_chain = create_stuff_documents_chain(llm, qa_prompt)
	convo_qa_chain = create_retrieval_chain(history_aware_retriever, qa_chain)
	return convo_qa_chain