from fastapi import UploadFile, APIRouter, UploadFile, File, Form,WebSocket, WebSocketDisconnect,HTTPException
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv
import tempfile
from typing import List
from langchain_community.document_loaders import PyPDFLoader
from .helperFunction import configuredLLM
router = APIRouter()

llm=""

@router.post("/uploadOrgFiles")
async def uploadOrgFiles(email: str = Form(...),
    files: List[UploadFile] = File(...)):
    globalDocuments=[]
    global llm
    files_list=[]
    load_dotenv()
    for file in files:
        content=await file.read()
        name=file.filename
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_file.write(content)
            tmp_file_path = tmp_file.name
            # Initialize the PDFLoader
            pdf_loader = PyPDFLoader(tmp_file_path)
            # Load text from the PDF
            globalDocuments.append(pdf_loader.load())
            #globalDocuments.append(documents)
        # background_task.add_task(gcpUploadFile,tmp_file_path,name,email)
    llm=configuredLLM(globalDocuments)
    return {"message":"files uploaded successfully"}


@router.websocket("/playground")
async def playgroundChat(websocket: WebSocket):
    global llm
    await websocket.accept()
    chatHistory=[]
    try:
        await websocket.send_text(f"Welcome to the Legments.AI")
        while True:
            question=await websocket.receive_text()
            print(question)
            response=llm.invoke({
                "context":"",
                "input": question,
                "chat_history": chatHistory,})
            chatHistory.extend([HumanMessage(content=question), response["answer"]])
            await websocket.send_text(response['answer'])
    except WebSocketDisconnect:
        print("WEBSOCKETDISCONNECT")
    except Exception as e:
       print(e)
       raise HTTPException(status_code=500, detail=f"Error{e}")
    finally:
        await websocket.close()

